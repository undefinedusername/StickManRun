var frogmodel={up:"images/texture/player_up.gif",down:"images/texture/player_down.gif",left:"images/texture/player_left.gif",right:"images/texture/player_right.gif"};
var frogmodela={up:"images/texture/frog2_up.gif",down:"images/texture/frog2_down.gif",left:"images/texture/frog2_left.gif",right:"images/texture/frog2_right.gif"};
var gamemode=78;
var updateButton = document.getElementById('updateDetails');
var cancelButton = document.getElementById('cancel');
var favDialog2 = document.getElementById('menuB');
var froga;
var myfont="Impact";
var myGamePiece;
var screenHeight;
var myObstacles = [];
var myBackground=[];
var myCoords;
var myScore;
var back=[];
var bot=[];
var gravityvar=0;
var level=1;
var score=0;
var myGameOver;
var mycredits;
var mycreditsA;
var forest;
var normal;
var ice;
var ocean;
var mycreditsB;
var myMusic;
var myDeathmusic;
var myButtonclick;
var gameoverimage;
var myHealth;
var dead;
var mycreditsC;
var frog;
var gameoverpiece;
var tool={
none:0,
brokenaxe:1,
axe:2,
brokensword:3,
sword:4,
bow:5,
arrow:6
};
var playerdef="images/player/Player2.png";
var Player={
randpos:Math.floor((Math.random() * 100) + 1),
type:1,
texture:"sanic.jpg",
health:1000,
damage:2,
tool:null,
score:0
};
function prevent(event){
event.preventDefault();
}

/*	http://stickmanrunner.blogspot.com/ */
function Timer(functionname,milliseconds){
setInterval(functionname,milliseconds);
}


function reloadpage(){
location.reload();
}
function sound(src) {
this.sound = document.createElement("audio");
this.sound.src = src;
this.sound.setAttribute("preload", "auto");
this.sound.setAttribute("controls", "none");
this.sound.style.display = "none";
document.body.appendChild(this.sound);
this.play = function(){
this.sound.play();
}
this.stop = function(){
this.sound.pause();
}
}
function addObstical(h, w, imageurl, positionX, positionY){
var error,x,screenHeight,minHeight,maxHeight,height,minGap,maxGap,gap;
x = myGameArea.canvas.width;
screenHeight=myGameArea.canvas.height;
minHeight = 20;
maxHeight = 200;
height = Math.floor(Math.random()*(maxHeight-minHeight+1)+minHeight);
minGap = 50;
maxGap = 200;
gap = Math.floor(Math.random()*(maxGap-minGap+1)+minGap);
if(h>myGameArea.canvas.height){
error="Error: height is higher than:" + myGameArea.canvas.height;
return error;
}else if(w>myGameArea.canvas.width){
error="Error: width is higher than:" + myGameArea.canvas.width;
}else{
myObstacles.push(new component(w,h,imageurl,positionX,positionY,"image"));
}
}
/*myCoords.text="X:	 " + getPlayerx() + "  Y: " + getPlayery();
myCoords.update();*/
var data={
save:function(tag,value){
localStorage.setItem(tag,value);
},
get:function(tag){
localStorage.getItem(tag);	
}
}
function startGame() {
myMusic = new sound('audio/music.mp3');
myMusic.play();
myDeathmusic= new sound('audio/gameover.mp3');
myhighscore=new component("30px",myfont,"red", 280, 150, "text");
myGamePiece = new component(30,30,Player.texture, 10, 120,"image");
/*myCoords = new component(30,myfont,"Blue",280,180,"text");*/
myScore = new component("30px",myfont,"red", 280, 40, "text");
myHealth = new component("30px",myfont, "red", 280, 100, "text");
myGameOver = new component("30px",myfont, "Black", 270,250, "text");
mycredits = new component("30px",myfont, "Black", 270,300, "text");
mycreditsA = new component("30px",myfont, "Black", 270,350, "text");
mycreditsB = new component("30px",myfont, "Black", 270,400, "text");
mycreditsC = new component("30px",myfont, "Black", 270,450, "text");
myGameArea.start();
}

function openwindow(websiteurl) {
window.open(websiteurl, "_blank", "toolbar=yes, scrollbars=yes, resizeable=yes, top=500, left=500, width=10000, height=10000");
}
var myGameArea = {
canvas : document.getElementById("viewport"),
start : function() {
this.canvas.width = 1000;
this.canvas.height = 400;
this.context = this.canvas.getContext("2d");
document.body.insertBefore(this.canvas, document.body.childNodes[0]);
this.frameNo = 0;
this.interval = setInterval(updateGameArea, 20);
window.addEventListener('keydown', function (e) {
myGameArea.keys = (myGameArea.keys || []);
myGameArea.keys[e.keyCode] = true;
})
window.addEventListener('keyup', function (e) {
myGameArea.keys[e.keyCode] = false; 
})
window.addEventListener('touchmove', function (e) {
myGameArea.x = e.touches[0].screenX;
myGameArea.y = e.touches[0].screenY;
})
window.addEventListener('mousedown', function (e) {
myGameArea.x = e.pageX;
myGameArea.y = e.pageY;
})
window.addEventListener('mouseup', function (e) {
myGameArea.x = false;
myGameArea.y = false;
})
window.addEventListener('touchstart', function (e) {
myGameArea.x = e.pageX;
myGameArea.y = e.pageY;
})
window.addEventListener('touchend', function (e) {
myGameArea.x = false;
myGameArea.y = false;
})
},
clear : function() {
this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
},
clearobs : function() {
this.context.clearRect(0, 0, 10, this.canvas.height);
}
}
function setCookie(cname,cvalue,exdays) {
var d = new Date();
d.setTime(d.getTime() + (exdays*24*60*60*1000));
var expires = "expires=" + d.toGMTString();
document.cookie = cname+"="+cvalue+"; "+expires;
}
function getCookie(cname) {
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) {
var c = ca[i];
while (c.charAt(0)==' ') {
c = c.substring(1);
}
if (c.indexOf(name) == 0) {
return c.substring(name.length, c.length);
}
}
return "";
}
function gameoverscreen(){
var temp1, temp2;
myGameArea.clear()
var temp1=myGameArea.frameNo;
if(data.get("score")<myGameArea.frameNo){
data.save("high_score",temp1);
}
data.save("score",temp1);
myGameOver.text="Game Over! " + "Score: " + myGameArea.frameNo;
myGameOver.update();
mycredits.text = "Made by: Noah Enger, Andrew";
mycredits.update();
mycreditsA.text = "Programmed By Noah Enger";
mycreditsA.update();
mycreditsB.text = "illustrated by Andrew Urban";
mycreditsB.update();
myDeathmusic.play();
myMusic.stop();
gameoverimage = new component(500,211,"images/Windows_98_-_Critical_Update_Notification.png",270,10,"image");
gameoverimage.update();
dead=true;
return dead;
}
function component(width, height, color, x, y, type) {
this.type = type;
if (type == "image" || type == "background") {
this.image = new Image();
this.image.src = color;
}
this.score = 0;
this.bounce = 0.6;
this.speed = 1;
this.width = width;
this.height = height;
this.speedX = 0;
this.speedY = 0;	
this.x = x;
this.y = y;
this.gravity = 0;
this.gravitySpeed = 0;
this.update = function() {
ctx = myGameArea.context;
if (type == "image" || type == "background") {
ctx.drawImage(this.image, 
this.x, 
this.y,
this.width, this.height);
if (type == "background") {
ctx.drawImage(this.image, 
this.x + this.width, this.y, this.width, this.height);
}
}else if (this.type == "text") {
ctx.font = this.width + " " + this.height;
ctx.fillStyle = color;
ctx.fillText(this.text, this.x, this.y);
}else {
ctx.fillStyle = color;
ctx.fillRect(this.x, this.y, this.width, this.height);
}
this.clicked = function() {
var myleft = this.x;
var myright = this.x + (this.width);
var mytop = this.y;
var mybottom = this.y + (this.height);
var clicked = true;
if ((mybottom < myGameArea.y) || (mytop > myGameArea.y)
|| (myright < myGameArea.x) || (myleft > myGameArea.x)) {
clicked = false;
}
return clicked;
}
}
this.newPos = function() {
this.x += this.speedX;
this.y += this.speedY;
if (this.type == "background") {
if (this.x == -(this.width)) {
this.x = 0;
}
}
}
this.newPosNpc = function() {
this.x += this.speed * Math.sin(this.angle);
this.y -= this.speed * Math.cos(this.angle);
}
this.hitBottom = function() {
var rockbottom = myGameArea.canvas.height - this.height;
if (this.y > rockbottom) {
this.gravitySpeed = -(this.gravitySpeed * this.bounce);
this.y = rockbottom;
this.gravitySpeed = 0;
}
}
this.crashWith = function(otherobj) {
var myleft = this.x;
var myright = this.x + (this.width);
var mytop = this.y;
var mybottom = this.y + (this.height);
var otherleft = otherobj.x;
var otherright = otherobj.x + (otherobj.width);
var othertop = otherobj.y;
var otherbottom = otherobj.y + (otherobj.height);
var crash = true;
if ((mybottom < othertop) || (mytop > otherbottom) || (myright < otherleft) || (myleft > otherright)) {
crash = false;
}
return crash;
}
}
function download(text, name, type) {
var a = document.getElementById("a");
var file = new Blob([text], {type: type});
a.href = URL.createObjectURL(file);
a.download = name;
}
function setmode(mode){
if(mode==="easy"){
gamemode=100;
}else if(mode==="normal"){
gamemode=58;
}else if(mode==="hard"){
gamemode=15;
}
}
function updateGameArea() {
var x, height, gap, minHeight, maxHeight, minGap, maxGap;
for (i = 0; i < myObstacles.length; i += 1) {
if (myGamePiece.crashWith(myObstacles[i])) {
health();
return;
} 
}
for (i = 0; i < bot.length; i += 1) {
if(myGamePiece.crashWith(bot[i])) {
gameoverscreen();
return;
} 
}
if(Player.health<=0){
gameoverscreen();
}
myGameArea.clear();
myGamePiece.speedX = 0;
myGamePiece.speedY = 0; 
if (myGameArea.keys && myGameArea.keys[87])/*w key*/ {move("up"); }
if (myGameArea.keys && myGameArea.keys[65])/*a key*/ {move("left"); }
if (myGameArea.keys && myGameArea.keys[83])/*s key*/ {move("down"); }
if (myGameArea.keys && myGameArea.keys[68])/*d key*/ {move("right"); }
if (myGameArea.touchX && myGameArea.touchY) {
myGamePiece.x = myGameArea.x;
myGamePiece.y = myGameArea.y;	
}
myGameArea.frameNo += 1;
if (myGameArea.frameNo == 1 || everyinterval(gamemode)) {
x = myGameArea.canvas.width;
screenHeight=myGameArea.canvas.height;
minHeight = 20;
maxHeight = 200;
height = Math.floor(Math.random()*(maxHeight-minHeight+1)+minHeight);
minGap = 50;
maxGap = 200;
gap = Math.floor(Math.random()*(maxGap-minGap+1)+minGap);

/*(width, height, color, x, y, type))*/
myObstacles.push(new component(16,16, "images/brick.png", x,height +gap, "image"));
myObstacles.push(new component(24,24, "images/brick.png", x,gap, "image"));
myObstacles.push(new component(12,24, "images/texture/sand.png", x, gap, "image"));	
myObstacles.push(new component(24,24, "images/brick.png", x,height +gap, "image"));
myObstacles.push(new component(24,24, "images/brick.png", x,gap, "image"));
myObstacles.push(new component(12,24, "images/texture/sand.png", x, gap, "image"));
myObstacles.push(new component(24,12, "images/texture/sand.png",x,0.10, "image"));	
}
for (i = 0; i < myObstacles.length; i += 1) {
myObstacles[i].x += -1;
myObstacles[i].update();
}
for (i - 0; i < bot.length; i += 1)	 {
bot[i].x += -1;
bot[i].update();
}
myGameArea.clearobs();
myScore.text="SCORE: " + myGameArea.frameNo;
myScore.update();
myHealth.text="Health: " + Player.health;
myHealth.update();
myGamePiece.newPos();
myGamePiece.update

/*top barrier*/bot.push(new component(80,50,"images/brick.png",x,0,"image"));
/*bottom barrier*/bot.push(new component(80,50,"images/brick.png",x,370,"image"));

}
function everyinterval(n) {
if ((myGameArea.frameNo / n) % 1 == 0) {return true;}
return false;
}


function getPlayerx(){
this.x=myGamePiece.x;
return this.x;
}
function getPlayery(){
this.y=myGamePiece.y;
return this.y;
}

function move(dir){
if(dir=="left"){
myGamePiece.speedX -= 1.5;
if(frog==true){
myGamePiece.image.src = frogmodel.left;
}else{
myGamePiece.image.src = frogmodela.left;
}
}else if(dir=="right"){
myGamePiece.speedX += 1.5;
if(frog==true){
myGamePiece.image.src = frogmodel.right;
}else{
myGamePiece.image.src = frogmodela.right;
}
}else if(dir=="down"){
myGamePiece.speedY += 1.5; 
if(frog==true){
myGamePiece.image.src = frogmodel.down;
}else{
myGamePiece.image.src = frogmodela.down;
}
}else if(dir=="up"){
myGamePiece.speedY -= 1.5;
if(frog==true){
myGamePiece.image.src = frogmodel.up;
}else{
myGamePiece.image.src = frogmodela.up;
}
}
}
function health(){
var damage=25;
var dead=false
if(dead==false && Player.health > 0){
Player.health-=damage;
myGamePiece.newPos();
myGamePiece.update();
myGamePiece.speedX += 10.5;
}else if(Player.health<=0){
dead=true;
myhighscore.text="High Score: " + data.get("high_score");
myGameArea.clear()
myGameOver.text="Game Over! " + "Score: " + myGameArea.frameNo;
myGameOver.update();
mycredits.text = "Made by: Noah Enger, Andrew";
mycredits.update();
mycreditsA.text = "Programmed By Noah Enger";
mycreditsA.update();
mycreditsB.text = "illustrated by Andrew Urban";
mycreditsB.update();
mycreditsC.text="Inspired by Travis Gomez!";
mycreditsC.update();
myDeathmusic.play();
myMusic.stop();
gameoverimage = new component(500,211,"images/Windows_98_-_Critical_Update_Notification.png",270,10,"image");
gameoverimage.update();
gameoverpiece = new component(30, 30,Player.texture, 10, 120,"image");
gameoverpiece.update();
}
}
function Optionsmenu(){
var updateButton = document.getElementById('updateDetails');
var cancelButton = document.getElementById('cancel');
var favDialog = document.getElementById('menuA');
var updateButton2=document.getElementById('mainmenu_options');
updateButton.addEventListener('click', function() {
favDialog.showModal();
});
updateButton2.addEventListener('click', function() {
favDialog.showModal();
});
cancelButton.addEventListener('click', function() {
favDialog.close();
});
}